#include<stdio.h>

#define cyanColor  "\x1B[36m"
#define redColor "\x1B[31m"
#define greenColor "\x1B[32m"
#define RESET "\x1B[0m"

int name() {
    char name[20];

    printf("Enter your name: ");
    scanf("%s", name);
    printf(cyanColor "Hello, %s!\n\n", name);
    printf(RESET);
    return 0;

}

int group() {
    int group;
    printf("1. Biology\n2. Computer Science\n3. Commerce\n");
    printf("\nSlect your group i.e(1 = Biology): ");
    scanf("%d", &group);
    return group;
}

int bio() {
    float eng, urd, pst, isl;
    float bio, phy, chem, maths, bioP, phyP, chemP;

    printf(greenColor "\nEnter the number of the following subjects: \n" RESET);

    printf(cyanColor "English: " RESET);
    scanf("%f", &eng);

    printf(cyanColor "Urdu: " RESET);
    scanf("%f", &urd);

    printf(cyanColor "Islamiyat: " RESET);
    scanf("%f", &isl);

    printf(cyanColor "Pakistan_Studies: " RESET);
    scanf("%f", &pst);
    
    printf(cyanColor "Maths: " RESET);
    scanf("%f", &maths);

    printf(cyanColor "Biology: " RESET);
    scanf("%f", &bio);

    printf(cyanColor "Physics: " RESET);
    scanf("%f", &phy);

    printf(cyanColor "Chemistry: " RESET);
    scanf("%f", &chem);

    printf(cyanColor "Biology-Practical: " RESET);
    scanf("%f", &bioP);

    printf(cyanColor "Physics-Practical: " RESET);
    scanf("%f", &phyP);

    printf(cyanColor "Chemistry-Practical: " RESET);
    scanf("%f", &chemP);


    // printf("Total: %f", eng+urd+pst+isl+bio+phy+chem+maths);
    if( (eng<25) || (urd<25) || (pst<13.3) || (isl<13.3) || (bio<21.66) || (phy<21.66) || (chem<21.66) || (maths<21.66) || (bioP<3.3) || (phyP<3.3) || (chemP<3.3)) {

        printf("Total Marks: %f", eng+urd+pst+isl+bio+phy+chem+maths+bioP+phyP+chemP);

        printf(redColor "\nStatus: FAIL\n" RESET);

    }
    else {
        printf("Total Marks: %f\n", eng+urd+pst+isl+bio+phy+chem+maths+bioP+phyP+chemP);

        printf("Percentage: %f\n", (eng+urd+pst+isl+bio+phy+chem+maths+bioP+phyP+chemP)/550*100);

        if( ((eng+urd+pst+isl+bio+phy+chem+maths+bioP+phyP+chemP)/550*100) < 33.3 ) {
            printf(redColor "\nStatus: FAIL\n" RESET);
        }
        else {
            printf(greenColor "Status: PASS\n" RESET);
        }
    }

    return 0;
}

int computer() {
    float eng, urd, pst, isl;
    float comp, phy, chem, maths, compP, phyP, chemP;

    printf(greenColor "\nEnter the number of the following subjects: \n" RESET);

    printf(cyanColor "English: " RESET);
    scanf("%f", &eng);

    printf(cyanColor "Urdu: " RESET);
    scanf("%f", &urd);

    printf(cyanColor "Islamiyat: " RESET);
    scanf("%f", &isl);

    printf(cyanColor "Pakistan_Studies: " RESET);
    scanf("%f", &pst);
    
    printf(cyanColor "Maths: " RESET);
    scanf("%f", &maths);

    printf(cyanColor "Computer_Science: " RESET);
    scanf("%f", &comp);

    printf(cyanColor "Physics: " RESET);
    scanf("%f", &phy);

    printf(cyanColor "Chemistry: " RESET);
    scanf("%f", &chem);

    printf(cyanColor "Computer-Practical: " RESET);
    scanf("%f", &compP);

    printf(cyanColor "Physics-Practical: " RESET);
    scanf("%f", &phyP);

    printf(cyanColor "Chemistry-Practical: " RESET);
    scanf("%f", &chemP);


    if( (eng<25) || (urd<25) || (pst<13.3) || (isl<13.3) || (comp<21.66) || (phy<21.66) || (chem<21.66) || (maths<21.66) || (compP<3.3) || (phyP<3.3) || (chemP<3.3)) {

        printf("Total Marks: %f", eng+urd+pst+isl+comp+phy+chem+maths+compP+phyP+chemP);

        printf(redColor "\nStatus: FAIL\n" RESET);

    }
    else {
        printf("Total Marks: %f\n", eng+urd+pst+isl+comp+phy+chem+maths+compP+phyP+chemP);

        printf("Percentage: %f\n", (eng+urd+pst+isl+comp+phy+chem+maths+compP+phyP+chemP)/550*100);

        if( ((eng+urd+pst+isl+comp+phy+chem+maths+compP+phyP+chemP)/550*100) < 33.3 ) {
            printf(redColor "\nStatus: FAIL\n" RESET);
        }
        else {
            printf(greenColor "Status: PASS\n" RESET);
        }

    }

    return 0;
}

int commerce() {
    float eng, urd, pst, isl;
    float comp, poc, poe, gmaths, compP;

    printf(greenColor "\nEnter the number of the following subjects: \n" RESET);

    printf(cyanColor "English: " RESET);
    scanf("%f", &eng);

    printf(cyanColor "Urdu: " RESET);
    scanf("%f", &urd);

    printf(cyanColor "Islamiyat: " RESET);
    scanf("%f", &isl);

    printf(cyanColor "Pakistan_Studies: " RESET);
    scanf("%f", &pst);
    
    printf(cyanColor "Maths: " RESET);
    scanf("%f", &gmaths);

    printf(cyanColor "Computer_Science: " RESET);
    scanf("%f", &comp);

    printf(cyanColor "P.O.C: " RESET);
    scanf("%f", &poc);

    printf(cyanColor "P.O.E: " RESET);
    scanf("%f", &poe);

    printf(cyanColor "Computer-Practical: " RESET);
    scanf("%f", &compP);


    if( (eng<25) || (urd<25) || (pst<13.3) || (isl<13.3) || (comp<21.66) || (poc<21.66) || (poe<21.66) || (gmaths<21.66) || (compP<3.3) ) {

        printf("Total Marks: %f", eng+urd+pst+isl+comp+poc+poe+gmaths+compP);

        printf(redColor "\nStatus: FAIL\n" RESET);

    }
    else {
        printf("Total Marks: %f\n", eng+urd+pst+isl+comp+poc+poe+gmaths+compP);

        printf("Percentage: %f\n", (eng+urd+pst+isl+comp+poc+poe+gmaths+compP)/550*100);

        if( ((eng+urd+pst+isl+comp+poc+poe+gmaths+compP)/550*100) < 33.3 ) {
            printf(redColor "\nStatus: FAIL\n" RESET);
        }
        else {
            printf(greenColor "Status: PASS\n" RESET);
        }
    }

    return 0;
}

int main(){
    int groupNumber;
    name(); 

    groupNumber = group();

    if(groupNumber == 1) {
        bio();
    }
    else if (groupNumber == 2) {
        computer();
    }
    else if (groupNumber == 3) {
        commerce();
    }
    else {
        printf(redColor"There are only 3 subject list\n");
    }

    return 0;
}